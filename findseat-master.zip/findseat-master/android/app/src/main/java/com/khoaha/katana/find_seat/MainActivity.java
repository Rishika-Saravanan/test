package com.khoaha.katana.find_seat;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
