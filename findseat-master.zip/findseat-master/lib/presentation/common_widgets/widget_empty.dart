import 'package:flutter/material.dart';

class WidgetEmpty extends StatelessWidget {
  WidgetEmpty();

  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
