export 'sc_show_info.dart';
export 'widget_offers.dart';
export 'widget_show_casts.dart';
export 'widget_show_desc.dart';
export 'widget_show_review.dart';
export 'widget_show_trailer.dart';
export 'widget_video_player.dart';
