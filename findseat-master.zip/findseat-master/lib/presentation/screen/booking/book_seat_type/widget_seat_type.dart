import 'package:flutter/material.dart';

class WidgetSeatType extends StatefulWidget {
  @override
  _WidgetSeatTypeState createState() => _WidgetSeatTypeState();
}

class _WidgetSeatTypeState extends State<WidgetSeatType> {
  @override
  Widget build(BuildContext context) {
    return Placeholder(
      fallbackHeight: 650,
    );
  }
}
